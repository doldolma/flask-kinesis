# coding: utf8
import boto3
from flask import current_app, request
from six.moves.queue import Empty, Queue


class flask_kinesis(object):

    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
            app.after_request(self.send_events)

            self.queue = Queue()
            self.kinesis = boto3.resource('kinesis')

    def init_app(self, app):
        if hasattr(app, "teardown_appcontext"):
            app.teardown_appcontext(self.send_events)
        else:
            app.teardown_request(self.send_events)

    def event(self, evt):
        self.queue(evt)

    def send_events(self, exception):
        while True:
            try:
                evt = self.queue.get_nowait()
            except Empty:
                break
        return Exception
